-- this is a sample custom configuration requesting to produce just one section
-- for all possible DEF values please review edb360_00_config.sql
DEF edb360_sections = '1a';
