Carlos Sierra's Shared Scripts 
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
last update: 2018/01/18

Feel free to use these scripts. They are mostly useful in the scope of SQL performance.
