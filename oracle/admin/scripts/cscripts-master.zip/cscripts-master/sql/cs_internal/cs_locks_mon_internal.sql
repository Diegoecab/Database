@@cs_locks_internal.sql
