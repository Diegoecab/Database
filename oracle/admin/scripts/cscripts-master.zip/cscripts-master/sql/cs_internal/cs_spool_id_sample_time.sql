--
PRO TIME_FROM    : "&&cs_entered_time_from." &&cs_sample_time_from. (&&cs_snap_id_from.) {&&cs_default_time_window.} 
PRO TIME_TO      : "&&cs_entered_time_to." &&cs_sample_time_to. (&&cs_snap_id_to.) {now} 
--
