--CLEAR SCREEN;
PRO
@@cs_spool_id_list.sql
--
