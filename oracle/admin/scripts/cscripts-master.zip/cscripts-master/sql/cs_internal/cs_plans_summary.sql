COL con_id FOR 999 HEA 'Con|ID';
COL pdb_name FOR A30 HEA 'PDB Name' FOR A30 TRUNC;
COL last_active_time FOR A19 HEA 'Last Active Time';
COL plan_hash_value FOR 9999999999 HEA 'Plan|Hash Value';
COL cursors FOR 9,999,990 HEA 'Child|Cursors';
COL valid FOR 9,999,990 HEA 'Valid|Cursors';
COL invalid FOR 9,999,990 HEA 'Invalid|Cursors';
COL obsolete FOR 9,999,990 HEA 'Obsolete|Cursors';
COL shareable FOR 9,999,990 HEA 'Shareable|Cursors';
COL bind_sens FOR 9,999,990 HEA 'Bind|Sensitive|Cursors';
COL bind_aware FOR 9,999,990 HEA 'Bind|Aware|Cursors';
COL executions FOR 999,999,999,999,990 HEA 'Total|Executions';
COL avg_et_ms_pe FOR 99,999,990.000 HEA 'Avg Elapsed|Time (ms)|Per Execution';
COL avg_cpu_ms_pe FOR 99,999,990.000 HEA 'Avg CPU|Time (ms)|Per Execution';
COL avg_bg_pe FOR 999,999,999,990 HEA 'Avg|Buffer Gets|Per Execution';
COL avg_disk_pe FOR 999,999,999,990 HEA 'Avg|Disk Reads|Per Execution';
COL avg_row FOR 999,999,990.000 HEA 'Avg Rows|Processed|Per Execution';
COL avg_et_ms_pr FOR 99,999,990.000 HEA 'Avg Elapsed|Time (ms)|Per Row Proc';
COL avg_cpu_ms_pr FOR 99,999,990.000 HEA 'Avg CPU|Time (ms)|Per Row Proc';
COL avg_bg_pr FOR 999,999,999,990 HEA 'Avg|Buffer Gets|Per Row Proc';
COL avg_disk_pr FOR 999,999,999,990 HEA 'Avg|Disk Reads|Per Row Proc';
--
PRO
PRO PLANS SUMMARY (v$sql)
PRO ~~~~~~~~~~~~~
SELECT s.con_id,
       c.name AS pdb_name,
       TO_CHAR(MAX(s.last_active_time), '&&cs_datetime_full_format.') AS last_active_time,
       s.plan_hash_value,
       COUNT(*) AS cursors,
       '|' AS "|",
       SUM(CASE SUBSTR(s.object_status, 1, 5) WHEN 'VALID' THEN 1 ELSE 0 END) AS valid,
       SUM(CASE SUBSTR(s.object_status, 1, 7) WHEN 'INVALID' THEN 1 ELSE 0 END) AS invalid,       
       SUM(CASE s.is_obsolete WHEN 'Y' THEN 1 ELSE 0 END) AS obsolete,
       SUM(CASE s.is_shareable WHEN 'Y' THEN 1 ELSE 0 END) AS shareable,
       SUM(CASE s.is_bind_sensitive WHEN 'Y' THEN 1 ELSE 0 END) AS bind_sens,
       SUM(CASE s.is_bind_aware WHEN 'Y' THEN 1 ELSE 0 END) AS bind_aware,
       '|' AS "|",
       SUM(s.executions) AS executions,
       SUM(s.elapsed_time)/NULLIF(SUM(s.executions), 0)/1e3 AS avg_et_ms_pe,
       SUM(s.cpu_time)/NULLIF(SUM(s.executions), 0)/1e3 AS avg_cpu_ms_pe,
       SUM(s.buffer_gets)/NULLIF(SUM(s.executions), 0) AS avg_bg_pe,
       SUM(s.disk_reads)/NULLIF(SUM(s.executions), 0) AS avg_disk_pe,
       SUM(s.rows_processed)/NULLIF(SUM(s.executions), 0) AS avg_row,
       '|' AS "|",
       SUM(s.elapsed_time)/NULLIF(SUM(s.rows_processed), 0)/1e3 AS avg_et_ms_pr,
       SUM(s.cpu_time)/NULLIF(SUM(s.rows_processed), 0)/1e3 AS avg_cpu_ms_pr,
       CASE WHEN SUM(s.cpu_time)/NULLIF(SUM(s.rows_processed), 0)/1e3 > &&cs_cpu_ms_per_row. THEN '*' END AS h,
       SUM(s.buffer_gets)/NULLIF(SUM(s.rows_processed), 0) AS avg_bg_pr,
       CASE WHEN SUM(s.buffer_gets)/NULLIF(SUM(s.rows_processed), 0) > &&cs_buffer_gets_per_row. THEN '*' END AS h,
       SUM(s.disk_reads)/NULLIF(SUM(s.rows_processed), 0) AS avg_disk_pr,
       CASE WHEN SUM(s.disk_reads)/NULLIF(SUM(s.rows_processed), 0) > &&cs_disk_reads_per_row. THEN '*' END AS h
  FROM v$sql s,
       v$containers c
 WHERE s.sql_id = '&&cs_sql_id.'
   AND c.con_id = s.con_id
 GROUP BY
       s.con_id, c.name, s.plan_hash_value
 ORDER BY
       1, 3, 4
/
PRO Note (H) = "*" means High. Expecting less than &&cs_cpu_ms_per_row. CPU ms per row processed, less than &&cs_buffer_gets_per_row. Buffer Gets per row processed, and less than &&cs_disk_reads_per_row. Disk Reads per row processed.
--


