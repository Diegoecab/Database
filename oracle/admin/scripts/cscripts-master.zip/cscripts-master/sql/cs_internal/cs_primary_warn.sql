PRO ***
PRO *** v$database.open_mode: &&open_mode.
PRO *** 
PRO
PAUSE Hit "return" to continue; or "control-c" then "return" to exit: 