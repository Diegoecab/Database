import sys
import logging
import psycopg2
import json
import os
from datetime import datetime

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
host = os.environ['HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
	try:
	  connection = psycopg2.connect(user=username, password=password, host=host, database=db_name)
	  cursor = connection.cursor()
	  sql = "INSERT INTO deliverables VALUES(1)"
	  logger.info("SUCCESS: Connection to Aurora Cluster Serverless succeeded")

	  cursor.execute(sql)
	  logger.info("INSERT executed on "+datetime.now())
	  conn.commit()
	  cur.close()
	except (Exception, psycopg2.DatabaseError) as error:
		print(error)
	finally:
		if conn is not None:
			conn.close() 
	  
